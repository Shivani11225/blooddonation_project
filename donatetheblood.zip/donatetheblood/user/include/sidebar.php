 <style type="text/css">
 
 .customNav{
 	position: absolute;
 	top: 4px;
 	left: 5px;
 }	
.customNav ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 410px;    
}

.customNav li a {
    display: block;
    padding: 8px 80px;
    text-decoration: none;

}



 </style>

<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">

<div class="customNav">
        <ul class="nav">

            <li class="active"><a href="index.php"><i class="fa fa-user" aria-hidden="true"></i><svg class="glyph stroked dashboard-dial"></svg>Dashboard</a></li>
            
            <li><a href="update.php"><i class="fa fa-edit" aria-hidden="true"></i><svg class="glyph stroked dashboard-dial"></svg>Update</a></li>
            
            
            <li><a href="logout.php"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i><svg class="glyph stroked dashboard-dial"></svg>Logout</a></li>
        </ul>
</div>
</div><!--/.sidebar-->